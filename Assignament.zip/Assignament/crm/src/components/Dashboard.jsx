import { Link } from 'react-router-dom';

export default function Dashboard() {
  return (
    <div className="p-4">
      <h1 className="text-2xl mb-4">Dashboard</h1>
      <nav className="space-x-4">
        <Link to="/products" className="text-blue-500">View Products</Link>
        <Link to="/add" className="text-blue-500">Add Product</Link>
      </nav>
    </div>
  );
}

