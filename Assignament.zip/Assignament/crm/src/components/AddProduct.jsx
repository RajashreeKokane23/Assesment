import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addProduct } from '../redux/productSlice';
import { useNavigate } from 'react-router-dom';

export default function AddProduct() {
  const [product, setProduct] = useState({ title: '', price: '' });
  const dispatch = useDispatch();
  const navigate = useNavigate();

  function handleSubmit(e) {
    e.preventDefault();
    dispatch(addProduct(product));
    navigate('/products');
  }

  return (
    <form onSubmit={handleSubmit} className="p-4 max-w-sm mx-auto">
      <h2 className="text-xl mb-4">Add Product</h2>
      <input className="border p-2 mb-2 w-full" placeholder="Title" onChange={e => setProduct({ ...product, title: e.target.value })} />
      <input className="border p-2 mb-2 w-full" placeholder="Price" type="number" onChange={e => setProduct({ ...product, price: e.target.value })} />
      <button className="bg-green-500 text-white px-4 py-2">Add</button>
    </form>
  );
}
