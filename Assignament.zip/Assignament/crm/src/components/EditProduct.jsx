import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updateProduct } from '../redux/productSlice';
import { useParams, useNavigate } from 'react-router-dom';

export default function EditProduct() {
  const { id } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { products } = useSelector(state => state.products);
  const existing = products.find(p => p.id === parseInt(id));
  const [product, setProduct] = useState(existing || { title: '', price: '' });

  useEffect(() => {
    if (existing) setProduct(existing);
  }, [existing]);

  function handleSubmit(e) {
    e.preventDefault();
    dispatch(updateProduct(product));
    navigate('/products');
  }

  return (
    <form onSubmit={handleSubmit} className="p-4 max-w-sm mx-auto">
      <h2 className="text-xl mb-4">Edit Product</h2>
      <input className="border p-2 mb-2 w-full" value={product.title} onChange={e => setProduct({ ...product, title: e.target.value })} />
      <input className="border p-2 mb-2 w-full" type="number" value={product.price} onChange={e => setProduct({ ...product, price: e.target.value })} />
      <button className="bg-yellow-500 text-white px-4 py-2">Update</button>
    </form>
  );
}
