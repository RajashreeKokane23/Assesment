import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const [user, setUser] = useState({ email: '', password: '' });
  const navigate = useNavigate();

  function handleLogin(e) {
    e.preventDefault();
    if (user.email === 'admin@test.com' && user.password === 'admin') {
      localStorage.setItem('token', 'fake-jwt-token');
      navigate('/dashboard');
    } else {
      alert('Invalid credentials');
    }
  }

  return (
    <form onSubmit={handleLogin} className="p-4 max-w-sm mx-auto">
      <h2 className="text-xl mb-4">Login</h2>
      <input className="border p-2 mb-2 w-full" type="email" placeholder="Email" onChange={e => setUser({ ...user, email: e.target.value })} />
      <input className="border p-2 mb-2 w-full" type="password" placeholder="Password" onChange={e => setUser({ ...user, password: e.target.value })} />
      <button className="bg-blue-500 text-white px-4 py-2" type="submit">Login</button>
    </form>
  );
}

