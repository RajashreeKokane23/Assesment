import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProducts, deleteProduct } from '../redux/productSlice';
import { Link } from 'react-router-dom';

export default function ProductList() {
  const dispatch = useDispatch();
  const { products } = useSelector(state => state.products);

  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  return (
    <div className="p-4">
      <h2 className="text-xl mb-4">Products</h2>
      <table className="table-auto w-full">
        <thead>
          <tr><th>ID</th><th>Title</th><th>Price</th><th>Actions</th></tr>
        </thead>
        <tbody>
          {products.map(p => (
            <tr key={p.id}>
              <td>{p.id}</td>
              <td>{p.title}</td>
              <td>${p.price}</td>
              <td>
                <Link to={`/edit/${p.id}`} className="text-blue-500">Edit</Link>
                <button onClick={() => dispatch(deleteProduct(p.id))} className="text-red-500 ml-2">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
